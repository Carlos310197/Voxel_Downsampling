%%
% Author: Carlos Huapaya
% Surface Reconstruction based on voxel downsampling
%%
close all;clear all;clc
%%
n_donuts = 6;% number of donuts to generate
% sphere = generate_sphere(n_donuts);% get the 1-radius sphere
% 
% % plot the sphere with the given number of donuts
% figure
% hold on
% for i = 1:n_donuts
%    scatter3(sphere(:,1,i),sphere(:,2,i),sphere(:,3,i))
% end
% axis vis3d
% hold off

% load point cloud data from mat file
% load('mining_data/esfera_ideal.mat');
load('mining_data/nube_puntos_sin_trasl.mat');
sphere = temp;clear temp;
scatter3(sphere(:,1),sphere(:,2),sphere(:,3))
axis vis3d

% Compute the downsampled cloud and plot
% leaf_size = [0.1,0.1,0.1];
leaf_size = [800,800,800];
point_cloud = permute(sphere,[1 3 2]);
point_cloud = reshape(point_cloud,[],size(sphere,2),1);
tic
[downsampled_cloud, idx_points, pos_out, repeat] = voxel_downsampling(point_cloud,leaf_size);
fprintf("Downsampling elapsed time: %.3f ms\n",toc*1000);
figure
scatter3(downsampled_cloud(:,1),downsampled_cloud(:,2),downsampled_cloud(:,3))
axis vis3d

% load surface 3d data from mat file
% load('mining_data/malla_triang_ideal.mat');
load('mining_data/malla_triangular_sin_trasl.mat');
surface = T; clear T;

% Generate the surface
surface = surface_reconstruction(surface, point_cloud,downsampled_cloud, n_donuts, idx_points, pos_out, repeat);

% DXF